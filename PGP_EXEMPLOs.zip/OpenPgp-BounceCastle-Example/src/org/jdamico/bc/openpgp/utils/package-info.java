/**
 * 
 */
/**
 * @author root
 *
 */
package org.jdamico.bc.openpgp.utils;