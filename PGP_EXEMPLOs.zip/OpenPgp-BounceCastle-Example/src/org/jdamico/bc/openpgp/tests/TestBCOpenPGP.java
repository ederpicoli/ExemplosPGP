package org.jdamico.bc.openpgp.tests;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Security;
import java.security.SignatureException;
import java.util.Iterator;

import org.bouncycastle.bcpg.ArmoredOutputStream;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPPrivateKey;
import org.bouncycastle.openpgp.PGPSignature;
import org.bouncycastle.openpgp.PGPSignatureGenerator;
import org.bouncycastle.openpgp.PGPSignatureSubpacketGenerator;
import org.bouncycastle.openpgp.PGPUtil;
import org.bouncycastle.openpgp.operator.jcajce.JcaPGPContentSignerBuilder;
import org.bouncycastle.openpgp.operator.jcajce.JcePBESecretKeyDecryptorBuilder;
import org.jdamico.bc.openpgp.utils.PgpHelper;
import org.jdamico.bc.openpgp.utils.RSAKeyPairGenerator;
import org.junit.Test;




public class TestBCOpenPGP {
	/*
	private boolean isArmored = true;
	private String id = "ederpicoli@gmail.com";
	private String passwd = "456789";
	private boolean integrityCheck = true;
	*/
	private boolean isArmored = true;
	private String id = "seninhajr@gmail.com";
	private String passwd = "456789";
	private boolean integrityCheck = true;

	private String pubKeyFile = 	"C:/KEY/orig/0x0A68B9818FF5E996.pub";	//Chave publica "KeyCIP"
	
	/*
	private String plainTextFile =		"C:/KEY/orig/Anotacoes.txt";		// Arquivo de entrada
	private String cipherTextFile = 	"C:/KEY/orig/Anotacoes.gpg";		// Arquivo criptografado
	private String decPlainTextFile = 	"C:/KEY/orig/dec-plain-text.txt";	// Arquivo n�o usado para criptografia
	private String signatureFile = 		"C:/KEY/orig/signat";				// Arquivo assinado
 	*/
	
	private String privKeyFile = 	"C:/KEY/orig/0xFB9FE230BAC708C5.sk";	//Chave Privada "KeyTelco"

	private String plainTextFile =		"C:/KEY/orig/Anotacoes.txt";		// Arquivo n�o usado na descriptografia
	private String cipherTextFile = 	"C:/KEY/orig/notes.txt.asc";		// Arquivo de entrada criptografado
	private String decPlainTextFile = 	"C:/KEY/orig/notes.txt";			// Arquivo de saida descriptografado
	private String signatureFile = 		"C:/KEY/orig/signature.txt";		// Arquivo assinado
	
	
	/*
	@Test
	public void genKeyPair() throws InvalidKeyException, NoSuchProviderException, SignatureException, IOException, PGPException, NoSuchAlgorithmException {

		RSAKeyPairGenerator rkpg = new RSAKeyPairGenerator();

		Security.addProvider(new BouncyCastleProvider());

		KeyPairGenerator    kpg = KeyPairGenerator.getInstance("RSA", "BC");

		kpg.initialize(1024);

		KeyPair				kp = kpg.generateKeyPair();

		FileOutputStream    out1 = new FileOutputStream(privKeyFile);
		FileOutputStream    out2 = new FileOutputStream(pubKeyFile);

		rkpg.exportKeyPair(out1, out2, kp.getPublic(), kp.getPrivate(), id, passwd.toCharArray(), isArmored);


	}
	 

	
	@Test
	public void encrypt() throws NoSuchProviderException, IOException, PGPException{
		FileInputStream pubKeyIs = new FileInputStream(pubKeyFile);
		FileOutputStream cipheredFileIs = new FileOutputStream(cipherTextFile);
		PgpHelper.getInstance().encryptFile(cipheredFileIs, plainTextFile, PgpHelper.getInstance().readPublicKey(pubKeyIs), isArmored, integrityCheck);
		cipheredFileIs.close();
		pubKeyIs.close();
	}
	 

	@Test
	public void decrypt() throws Exception{

		FileInputStream cipheredFileIs = new FileInputStream(cipherTextFile);
		FileInputStream privKeyIn = new FileInputStream(privKeyFile);
		FileOutputStream plainTextFileIs = new FileOutputStream(decPlainTextFile);
		PgpHelper.getInstance().decryptFile(cipheredFileIs, plainTextFileIs, privKeyIn, passwd.toCharArray());
		cipheredFileIs.close();
		plainTextFileIs.close();
		privKeyIn.close();
	}
	*/
	@Test
	public void signAndVerify() throws Exception{
		FileInputStream KeySec = new FileInputStream(privKeyFile);
		FileInputStream pubKeyIs = new FileInputStream(pubKeyFile);
		FileInputStream plainTextInput = new FileInputStream(plainTextFile);
		FileOutputStream Out = new FileOutputStream(signatureFile);
				
		//byte[] bIn = PgpHelper.getInstance().inputStreamToByteArray(plainTextInput);
		//byte[] sig = PgpHelper.getInstance().createSignature(plainTextFile, privKeyIn, signatureOut, passwd.toCharArray(), true);
		//PgpHelper.getInstance().verifySignature(plainTextFile, sig, pubKeyIs);
		
		char[] pass = passwd.toCharArray();
		
		//byte[] messageCharArray = message.getBytes();
		byte[] messageCharArray = inputStreamToByteArray(plainTextInput);

		ByteArrayOutputStream encOut = new ByteArrayOutputStream();
		
		OutputStream out = encOut;
		if (isArmored) {
			out = new ArmoredOutputStream(out);
		}
		// Unlock the private key using the password
		KeySec = pgpSec.extractPrivateKey(new JcePBESecretKeyDecryptorBuilder().setProvider("BC").build(pass));

		// Signature generator, we can generate the public key from the private // key! Nifty!
		PGPSignatureGenerator sGen = new PGPSignatureGenerator(new JcaPGPContentSignerBuilder(pgpSec.getPublicKey().getAlgorithm(), PGPUtil.SHA1).setProvider("BC"));

		sGen.init(PGPSignature.BINARY_DOCUMENT, pgpPrivKey);

		Iterator it = pgpSec.getPublicKey().getUserIDs();
			if (it.hasNext()) {
				PGPSignatureSubpacketGenerator spGen = new PGPSignatureSubpacketGenerator();
				spGen.setSignerUserID(false, (String) it.next());
				sGen.setHashedSubpackets(spGen.generate());
			}
			
		//PGPCompressedDataGenerator comData = new PGPCompressedDataGenerator(PGPCompressedData.ZLIB);
		ArmoredOutputStream comData = new ArmoredOutputStream(encOut1);
		
		comData.beginClearText(PGPUtil.SHA256);
		
		sGen.update(messageCharArray);
		
		comData.write(messageCharArray);
		
		comData.endClearText();
		
		BCPGOutputStream bOut = new BCPGOutputStream(comData);
		
		sGen.generateOnePassVersion(false).encode(bOut);
		
			PGPLiteralDataGenerator lGen = new PGPLiteralDataGenerator();
			
				OutputStream lOut = lGen.open(bOut, PGPLiteralData.BINARY, PGPLiteralData.CONSOLE, messageCharArray.length, new Date());

			for (byte c : messageCharArray) {
				lOut.write(c);
				sGen.update(c);
			}
			lOut.close();
			
			lGen.close();
			
		sGen.generate().encode(bOut);
		
		comData.close();
		
		out.close();
		
		return encOut1.toString();
	}


	private byte[] inputStreamToByteArray(FileInputStream plainTextInput) {
		// TODO Auto-generated method stub
		return null;
	}
	
	//}
	
	
}
