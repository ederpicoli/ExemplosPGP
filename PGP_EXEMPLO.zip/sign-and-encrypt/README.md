PGP-Sign-and-Encrypt
====================

Java example of using a set of PGP Key's to generated a PGP signature based on an input string, and then encrypt that string using Bouncy Castle
